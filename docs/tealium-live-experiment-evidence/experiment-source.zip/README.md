# Tealium experiment

This is an isolated diagnostic prototype. It is not an installed product change,
an approved feature specification, or release evidence.

Run from the repository root with the locked Node runtime and Google Chrome:

```sh
node tmp/tealium-experiment/stage1.mjs
node tmp/tealium-experiment/stage2.mjs
node tmp/tealium-experiment/stage3.mjs
```

Chrome needs local process sockets. In the Codex sandbox, request permission for
these exact commands. Do not disable the Chrome sandbox. All browser profiles
and temporary files use this repository's `tmp/` directory. External host names
are blocked in the experiment browser; the fixture also applies a local-only
content security policy. The downloaded runtime can attempt blocked requests.

The archive excludes third-party runtime code. For reproduction, obtain
`https://tags.tiqcdn.com/utag/tealium/docs/prod/utag.js` and save it as
`tmp/tealium-experiment/vendor/utag.js`. The tested SHA-256 is
`82882bb70abe78a85629baf4859ce01710fd92d1270b025cfdafd8ef9d324b89`.
Different bytes are a new runtime sample, not a reproduction of this evidence.

`extension/host/` contains seven unchanged modules copied from the current
`dist/` tree. Their source paths and hashes are in `evidence/host-modules.json`.
The other utilities are labelled placeholders. The actual retained-page and
workspace-navigation implementations are used. The test does not exercise the
complete Data Layer application or the browser side-panel container.

Stage 1 uses seven page cases and one late-tag transition. Stage 2 uses four
source selections and four stale-page rejections. Stage 3 contains fourteen
behavior checks and one small-fixture timing observation. Timing is diagnostic;
it does not establish production overhead.

Known limits: one real published Tealium version; controlled separate/custom
tag fixtures; no real DNS CNAME; main frame only; no same-URL reload generation
check; no firing history or vendor delivery proof; fixed localhost permission;
no activeTab permission-recovery proof; no duplicate-function/wrapped-function
compatibility proof; no long-running background-timer or complete scroll proof.

`Target.openDevTools` in stage 3 is a privileged browser automation command
that represents the user opening DevTools. The extension itself does not call
it and does not have debugger permission.
