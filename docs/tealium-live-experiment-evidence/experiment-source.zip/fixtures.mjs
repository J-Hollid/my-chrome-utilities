import http from 'node:http';
import {readFile} from 'node:fs/promises';
export async function fixtureServer() {
  const real = await readFile(new URL('vendor/utag.js',import.meta.url));
  const hits=[];
  const base = `window.utag={view(){},link(){},loader:{cfg:{}},sender:{},cfg:{path:location.origin+'/custom/'},o:{},handler:{iflag:1}};utag.o['shop.main']=utag;`;
  const bundle = `utag.loader.cfg['34']={title:'Bundled example'};utag.sender['34']={send:function bundledSend(){return 'bundle-34';}};`;
  const assets = {
    '/custom/utag.js':base+bundle,
    '/custom/utag.21.js':`utag.loader.cfg['21']={title:'Separate example'};utag.sender['21']={send:function separateSend(){return 'separate-21';}};`,
    '/custom/vendor-special.js':`utag.loader.cfg['52']={title:'Custom source'};utag.sender['52']={send:function customSend(){return 'custom-52';}};`,
    '/custom/utag.99.js':`utag.loader.cfg['99']={title:'Late tag'};utag.sender['99']={send:function lateSend(){return 'late-99';}};`,
    '/decoy/utag.7.js':`window.unrelated=true;`,
    '/custom/payload.js':base+bundle,
  };
  const bodies = {
    absent:'',
    decoy:`<script src='/decoy/utag.7.js'></script><script>window.utag={unrelated:true}</script>`,
    queue:`<script>window.utag={e:[],view(){},link(){}}</script>`,
    separate:`<script src='/custom/utag.js'></script><script src='/custom/utag.21.js?revision=exact'></script>`,
    custom:`<script src='/custom/payload.js'></script><script id='utag_shop.main_52' src='/custom/vendor-special.js?v=52'></script>`,
    real:`<script>window.utag_data={tealium_event:'page_view'};window.utag_cfg_ovrd={path:location.origin+'/custom/'};</script><script src='/custom/real-payload.js?revision=original'></script>`,
    multiple:`<script src='/custom/utag.js'></script><script>utag.o['shop.second']={view(){},link(){},loader:{cfg:{'34':{title:'Other profile'}}},sender:{'34':{send:function otherSend(){return 'second-profile';}}},cfg:{path:location.origin+'/second/'}};</script>`,
  };
  const server = http.createServer(async(req,res)=>{
    hits.push(req.url);
    const url=new URL(req.url,'http://local');
    res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self'; frame-src 'none'");
    if (url.pathname==='/custom/real-payload.js') {res.setHeader('Content-Type','text/javascript');res.end(real);return;}
    if (assets[url.pathname]) {res.setHeader('Content-Type','text/javascript');res.end(assets[url.pathname]);return;}
    const name=url.pathname.slice(1);
    if (Object.hasOwn(bodies,name)) {res.setHeader('Content-Type','text/html');res.end(`<!doctype html><title>Tealium experiment: ${name}</title><h1>${name}</h1>${bodies[name]}`);return;}
    res.writeHead(404);res.end();
  });
  await new Promise(done=>server.listen(0,'127.0.0.1',done));
  return {origin:`http://127.0.0.1:${server.address().port}`,hits,close:()=>server.close()};
}
