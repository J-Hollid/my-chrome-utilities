import {detectTealium} from './detect.mjs';
const evaluate=expression=>new Promise((resolve,reject)=>chrome.devtools.inspectedWindow.eval(expression,(value,error)=>error?.isException?reject(Error(error.value)):resolve(value)));
const snapshot=()=>evaluate(`(${detectTealium.toString()})()`);
const resources=()=>new Promise(resolve=>chrome.devtools.inspectedWindow.getResources(resolve));
const content=resource=>new Promise(resolve=>resource.getContent((text,encoding)=>resolve(encoding==='base64'?atob(text):text)));

async function sourceFor(tag) {
  const available=await resources();
  if(tag.sourceUrl&&available.some(r=>r.url===tag.sourceUrl)) return {url:tag.sourceUrl,line:0,column:0,evidence:'Exact observed resource'};
  if(!tag.sendSource) throw Error('No source evidence');
  const matches=[];
  for(const resource of available.filter(r=>/^https?:/.test(r.url))) {
    const text=await content(resource);
    const offset=text?.indexOf(tag.sendSource)??-1;
    if(offset<0) continue;
    if(text.indexOf(tag.sendSource,offset+1)>=0) throw Error('Ambiguous source within resource');
    const before=text.slice(0,offset),line=before.split('\n').length-1,column=offset-(before.lastIndexOf('\n')+1);
    matches.push({url:resource.url,line,column,evidence:'Exact registered function found in resource'});
  }
  if(matches.length!==1) throw Error(`Source is ${matches.length?'ambiguous':'unresolved'}`);
  return matches[0];
}
async function showTag(key,expectedUrl) {
  const current=await snapshot();
  if(current.url!==expectedUrl) throw Error('Stale page selection');
  const tag=current.tags.find(t=>t.key===key);
  if(!tag) throw Error('Tag no longer available');
  const source=await sourceFor(tag);
  await new Promise(resolve=>chrome.devtools.panels.openResource(source.url,source.line,source.column,resolve));
  return {key,...source,tabId:chrome.devtools.inspectedWindow.tabId};
}
window.experiment={snapshot,sourceFor,showTag,tabId:chrome.devtools.inspectedWindow.tabId};
const port=chrome.runtime.connect({name:'tealium-devtools'});
port.postMessage({type:'hello',tabId:chrome.devtools.inspectedWindow.tabId});
port.onMessage.addListener(async message=>{
  if(message.type!=='show-tag')return;
  try{port.postMessage({requestId:message.requestId,ok:true,source:await showTag(message.key,message.expectedUrl)});}
  catch(error){port.postMessage({requestId:message.requestId,ok:false,error:error.message});}
});
