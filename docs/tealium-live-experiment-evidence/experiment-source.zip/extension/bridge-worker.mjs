const ports=new Map(),pending=new Map();
chrome.runtime.onConnect.addListener(port=>{
  if(port.name!=='tealium-devtools'||port.sender?.id!==chrome.runtime.id)return;
  let tabId;
  port.onMessage.addListener(message=>{
    if(message.type==='hello'){tabId=message.tabId;ports.set(tabId,port);return;}
    const slot=pending.get(message.requestId);
    if(slot){clearTimeout(slot.timer);pending.delete(message.requestId);slot.respond(message);}
  });
  port.onDisconnect.addListener(()=>{if(ports.get(tabId)===port)ports.delete(tabId);});
});
chrome.runtime.onMessage.addListener((message,sender,respond)=>{
  if(sender.id!==chrome.runtime.id)return;
  const port=ports.get(message.tabId);
  if(message.type==='devtools-status'){respond({connected:Boolean(port)});return;}
  if(message.type!=='show-tag')return;
  if(!port){respond({ok:false,error:'Open DevTools for the selected website tab.'});return;}
  const requestId=crypto.randomUUID();
  const timer=setTimeout(()=>{pending.delete(requestId);respond({ok:false,error:'DevTools did not respond.'});},5000);
  pending.set(requestId,{respond,timer});port.postMessage({...message,requestId});return true;
});
