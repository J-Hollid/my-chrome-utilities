// Experiment only. Reads a page; never calls Tealium tracking or loader functions.
export function detectTealium() {
  const root = window.utag;
  const scripts = [...document.scripts].filter(s => s.src).map(s => ({url:s.src,id:s.id}));
  const resources = [...new Set([...scripts.map(s => s.url),
    ...performance.getEntriesByType('resource').map(r => r.name)])];
  const runtimeShape = u => u && typeof u.view === 'function' && typeof u.link === 'function'
    && u.loader && typeof u.loader === 'object' && u.sender && typeof u.sender === 'object'
    && u.cfg && typeof u.cfg === 'object';
  const objects = Object.entries(root?.o || {}).filter(([,u]) => runtimeShape(u));
  if (runtimeShape(root) && !objects.some(([,u]) => u === root)) objects.unshift(['default',root]);
  const queue = root && typeof root.view === 'function' && Array.isArray(root.e);
  if (!objects.length) return {state:queue?'Initializing':'Not detected',url:location.href,tags:[],resources};
  const tags = [];
  for (const [profile,u] of objects) {
    const ids = [...new Set([...Object.keys(u.loader.cfg||{}), ...Object.keys(u.sender)])];
    for (const uid of ids) {
      const config = u.loader.cfg?.[uid], sender = u.sender[uid];
      if (!/^\d+$/.test(uid)) continue;
      const known = resources.filter(url => {
        const parsed = new URL(url);
        return parsed.pathname.endsWith(`/utag.${uid}.js`) &&
          (!u.cfg.path || url.startsWith(new URL(u.cfg.path,location.href).href));
      });
      const byId = scripts.filter(s => s.id === `utag_${profile}_${uid}`).map(s=>s.url);
      const candidates = [...new Set([...byId,...known])];
      tags.push({key:`${profile}:${uid}`,profile,uid,name:config?.title||`Tag ${uid}`,
        state:typeof sender?.send === 'function'?'Code registered':'Configured',
        sourceUrl:candidates.length===1?candidates[0]:null,
        sourceEvidence:candidates.length===1?'Observed resource':'Needs source inspection',
        sourceCandidates:candidates, sendSource:typeof sender?.send==='function'?Function.prototype.toString.call(sender.send):null});
    }
  }
  return {state:'Detected',url:location.href,version:root.cfg?.v||root.cfg?.template||null,
    loadingSuppressed:root.cfg?.noload===true||root.cfg?.noload===1,
    initialized:root.handler?.iflag===1,tags,resources};
}
