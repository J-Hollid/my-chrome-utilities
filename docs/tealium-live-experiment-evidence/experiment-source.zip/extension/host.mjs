import {mountUtilityWorkspace} from './host/utility-host/workspace.js';
const picker=document.querySelector('#target-picker');
for(const tab of await chrome.tabs.query({url:'http://127.0.0.1/*'})) {
  const option=document.createElement('option');option.value=String(tab.id);option.textContent=tab.url;picker.append(option);
}
window.workspace=mountUtilityWorkspace({document,page:window,storage:localStorage,
  contributions:[{id:'tealium',label:'Tealium',page:'live.html',storage:{namespace:'utility.tealium.experiment',version:1}}],
  selectTarget:async()=>picker.value?Number(picker.value):null,
  subscribeTargetClosed:callback=>{chrome.tabs.onRemoved.addListener(callback);return()=>chrome.tabs.onRemoved.removeListener(callback);}});
window.hostReady=true;
