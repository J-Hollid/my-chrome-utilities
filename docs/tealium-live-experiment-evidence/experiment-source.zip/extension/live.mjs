import {connectUtilityPage} from './host/utility-host/page-client.js';
import {detectTealium} from './detect.mjs';
import {render} from './render.mjs';
let timer,busy=false;
let state={status:'Ready',snapshot:null,selected:null,search:'',connected:false,feedback:'',error:null,polls:0};
const client=connectUtilityPage(window,message=>{
  if(message.kind==='state'&&!client.ownsWork&&message.payload){state=message.payload;paint();}
  if(message.kind==='action'&&client.ownsWork)void action(message.payload);
  if(message.kind==='target-closed'){clearInterval(timer);state.status='Target closed';publish();}
  if(message.kind==='close'||message.kind==='stop'||message.kind==='reset'){clearInterval(timer);state.status='Ended';publish();}
});
function paint(){render(state,key=>void request({kind:'select',key}));}
function publish(){paint();if(client.ownsWork)client.send('state',state);}
async function scan(){
  if(busy||state.status!=='Observing')return;
  busy=true;
  try{
    const results=await chrome.scripting.executeScript({target:{tabId:client.identity.targetId},world:'MAIN',func:detectTealium});
    if(state.status!=='Observing')return;
    const next=results[0].result;
    if(state.snapshot&&state.snapshot.url!==next.url){state.selected=null;state.feedback='Page changed; previous selection cleared.';}
    state.snapshot=next;state.error=null;state.polls++;
    const status=await chrome.runtime.sendMessage({type:'devtools-status',tabId:client.identity.targetId});state.connected=status.connected;
  }catch(error){state.error=`Target unavailable: ${error.message}`;}
  finally{busy=false;publish();}
}
async function action(value){
  if(value.kind==='start'){state.status='Observing';clearInterval(timer);timer=setInterval(scan,250);await scan();}
  if(value.kind==='pause'){state.status=state.status==='Paused'?'Observing':'Paused';if(state.status==='Observing')await scan();}
  if(value.kind==='end'){state.status='Ended';clearInterval(timer);}
  if(value.kind==='select'){state.selected=value.key;state.feedback='';}
  if(value.kind==='search')state.search=value.value;
  if(value.kind==='source'){
    const result=await chrome.runtime.sendMessage({type:'show-tag',tabId:client.identity.targetId,key:state.selected,expectedUrl:state.snapshot.url});
    state.feedback=result.ok?`Opened ${result.source.url}`:result.error;
  }
  publish();
}
function request(value){if(client.ownsWork)return action(value);client.send('action',value);}
for(const [id,kind]of[['start','start'],['pause','pause'],['end','end'],['show-source','source']])document.getElementById(id).onclick=()=>void request({kind});
document.getElementById('back').onclick=()=>void request({kind:'select',key:null});
document.getElementById('search').oninput=event=>void request({kind:'search',value:event.target.value});
window.addEventListener('pagehide',()=>clearInterval(timer));
window.liveExperiment={get state(){return state;},identity:client.identity,ownsWork:client.ownsWork,scan};
paint();
