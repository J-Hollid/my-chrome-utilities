const find=id=>document.getElementById(id),rows=new Map();
export function render(state,select) {
  const tag=state.snapshot?.tags.find(t=>t.key===state.selected);
  find('target').textContent=state.snapshot?.url||'Selected website';
  find('status').textContent=state.error||`${state.status}${state.snapshot?' · '+state.snapshot.tags.length+' tags detected':''}`;
  find('start').hidden=state.status==='Observing'||state.status==='Paused';
  find('start').disabled=state.status==='Target closed';
  find('pause').hidden=!['Observing','Paused'].includes(state.status);
  find('pause').textContent=state.status==='Paused'?'Resume observation':'Pause observation';
  find('end').hidden=!['Observing','Paused'].includes(state.status);
  find('search').value=state.search;
  const tags=state.snapshot?.tags||[],filtered=tags.filter(t=>(t.name+' '+t.uid).toLowerCase().includes(state.search.toLowerCase()));
  for(const [key,row] of rows)if(!tags.some(t=>t.key===key)){row.remove();rows.delete(key);}
  for(const item of tags){let row=rows.get(item.key);if(!row){row=document.createElement('button');row.className='tag';row.dataset.key=item.key;row.append(document.createElement('strong'),document.createElement('small'));row.onclick=()=>select(item.key);rows.set(item.key,row);find('tags').append(row);}
    row.hidden=!filtered.includes(item);row.setAttribute('aria-selected',String(item.key===state.selected));row.firstChild.textContent=`${item.uid} · ${item.name}`;row.lastChild.textContent=item.state;}
  find('count').textContent=`${filtered.length} of ${tags.length}`;
  find('inspector').hidden=!tag;document.querySelector('.live-work').classList.toggle('selected',Boolean(tag));
  if(tag){find('tag-title').textContent=tag.name;find('tag-uid').textContent=tag.uid;find('tag-profile').textContent=tag.profile;find('tag-evidence').textContent=tag.state;find('tag-source').textContent=tag.sourceUrl||'Resolve from the loaded source in DevTools';}
  find('devtools').textContent=state.connected?'DevTools connected':'Open DevTools for this website to inspect its source.';
  find('show-source').disabled=!state.connected||state.status==='Target closed';find('feedback').textContent=state.feedback||'';
}
