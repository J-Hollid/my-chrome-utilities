import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {startBrowser,until} from './browser.mjs';
import {fixtureServer} from './fixtures.mjs';
import {detectTealium} from './extension/detect.mjs';
const started=Date.now(),site=await fixtureServer(),browser=await startBrowser();
const results=[];
try {
  for (const name of ['absent','decoy','queue','separate','custom','real','multiple']) {
    const url=`${site.origin}/${name}`;
    const {targetId}=await browser.call('Target.createTarget',{url});
    const page=await browser.attach(targetId);
    await until(()=>page.evaluate('({url:location.href,ready:document.readyState})'),v=>v.url===url&&v.ready==='complete',name);
    const data=await page.evaluate(`(${detectTealium.toString()})()`);
    if(name==='absent'||name==='decoy') assert.equal(data.state,'Not detected');
    if(name==='queue') assert.equal(data.state,'Initializing');
    if(name==='separate') {assert.equal(data.tags.length,2);assert.equal(data.tags.find(t=>t.uid==='21').sourceUrl,site.origin+'/custom/utag.21.js?revision=exact');}
    if(name==='custom') assert.equal(data.tags.find(t=>t.uid==='52').sourceUrl,site.origin+'/custom/vendor-special.js?v=52');
    if(name==='real') {assert.equal(data.state,'Detected');assert.equal(data.tags[0].uid,'115');assert.equal(data.tags[0].sourceUrl,null);assert.equal(data.loadingSuppressed,true);}
    if(name==='multiple') {assert.equal(data.tags.length,2);assert.equal(new Set(data.tags.map(t=>t.key)).size,2);}
    if(name==='separate') {
      await page.evaluate(`new Promise(resolve=>{const s=document.createElement('script');s.src='/custom/utag.99.js';s.onload=resolve;document.head.append(s)})`);
      const next=await page.evaluate(`(${detectTealium.toString()})()`);assert(next.tags.some(t=>t.uid==='99'));
      results.push({case:'late tag',status:'passed',tag:'99'});
    }
    results.push({case:name,status:'passed',observation:{...data,tags:data.tags.map(({sendSource,...tag})=>({...tag,sendSourceLength:sendSource?.length||0}))}});
    await browser.call('Target.closeTarget',{targetId});
  }
  const report={startedAt:new Date(started).toISOString(),elapsedMs:Date.now()-started,browser:browser.version,results,requests:site.hits};
  await writeFile(new URL('evidence/stage1.json',import.meta.url),JSON.stringify(report,null,2));
  console.log(JSON.stringify({passed:results.length,elapsedMs:report.elapsedMs,realRuntime:results.find(r=>r.case==='real').observation},null,2));
} finally {await browser.close();site.close();}
