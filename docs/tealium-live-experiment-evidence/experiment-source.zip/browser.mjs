import { spawn } from 'node:child_process';
import { mkdtemp, rm } from 'node:fs/promises';
import { resolve } from 'node:path';

export async function startBrowser(extra = []) {
  const profile = await mkdtemp(resolve('tmp/tx-'));
  const proc = spawn('/usr/bin/google-chrome', [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--disable-background-networking', '--disable-component-update', '--disable-sync',
    '--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE localhost, EXCLUDE 127.0.0.1',
    '--remote-debugging-pipe', '--enable-unsafe-extension-debugging',
    `--user-data-dir=${profile}`, ...extra, 'about:blank',
  ], { stdio: ['ignore', 'ignore', 'pipe', 'pipe', 'pipe'],
    env: { ...process.env, XDG_CONFIG_HOME: profile, TMPDIR: profile } });
  let sequence = 0, buffer = '', stderr = '';
  const pending = new Map(), listeners = new Set();
  proc.stderr.on('data', data => { stderr = (stderr + data).slice(-3000); });
  for (const stream of [proc.stdio[3], proc.stdio[4]]) stream.on('error', () => {});
  proc.on('exit', code => {
    for (const slot of pending.values()) { clearTimeout(slot.timer); slot.reject(Error(`Chrome exit ${code}: ${stderr}`)); }
    pending.clear();
  });
  proc.stdio[4].on('data', data => {
    buffer += data;
    let end;
    while ((end = buffer.indexOf('\0')) !== -1) {
      const message = JSON.parse(buffer.slice(0, end)); buffer = buffer.slice(end + 1);
      if (message.id) {
        const slot = pending.get(message.id);
        if (slot) { pending.delete(message.id); clearTimeout(slot.timer);
          message.error ? slot.reject(Error(JSON.stringify(message.error))) : slot.resolve(message.result); }
      } else for (const listener of listeners) listener(message);
    }
  });
  function call(method, params = {}, sessionId) {
    return new Promise((resolveCall, reject) => {
      const id = ++sequence;
      const timer = setTimeout(() => { pending.delete(id); reject(Error(`${method} timed out: ${stderr}`)); }, 15000);
      pending.set(id, { resolve: resolveCall, reject, timer });
      proc.stdio[3].write(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }) + '\0');
    });
  }
  async function attach(targetId) {
    const { sessionId } = await call('Target.attachToTarget', { targetId, flatten: true });
    return {
      targetId, sessionId, call: (method, params) => call(method, params, sessionId),
      async evaluate(expression) {
        const r = await call('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true }, sessionId);
        if (r.exceptionDetails) throw Error(JSON.stringify(r.exceptionDetails));
        return r.result.value;
      },
    };
  }
  async function close() {
    try { await call('Browser.close'); } catch {}
    if (proc.exitCode === null) await new Promise(done => {
      const timer = setTimeout(() => { proc.kill('SIGKILL'); done(); }, 2000);
      proc.once('exit', () => { clearTimeout(timer); done(); });
    });
    for (const slot of pending.values()) { clearTimeout(slot.timer); slot.reject(Error('Browser closed')); }
    await rm(profile, { recursive: true, force: true });
  }
  let version;
  try { version = await call('Browser.getVersion'); }
  catch (error) { await rm(profile, { recursive:true, force:true }); throw error; }
  return { call, attach, close, version, on: listener => listeners.add(listener) };
}

export async function until(work, predicate, description, milliseconds = 5000) {
  const deadline = Date.now() + milliseconds;
  let result;
  do { result = await work(); if (predicate(result)) return result;
    await new Promise(done => setTimeout(done, 50));
  } while (Date.now() < deadline);
  throw Error(`${description}: ${JSON.stringify(result)}`);
}
