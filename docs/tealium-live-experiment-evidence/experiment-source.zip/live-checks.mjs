import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {until} from './browser.mjs';
export const liveEval=(host,expression)=>host.evaluate(`(()=>{const w=document.querySelector('#workspace-panel-tealium iframe').contentWindow;return (${expression})(w,w.document);})()`);
export async function state(host){return liveEval(host,'w=>w.liveExperiment.state');}
export async function waitState(host,predicate,label){return until(()=>state(host),predicate,label);}
export async function click(host,id){return liveEval(host,`(w,d)=>d.getElementById(${JSON.stringify(id)}).click()`);}
export async function layout(host,width,name){
  await host.call('Emulation.setDeviceMetricsOverride',{width,height:900,deviceScaleFactor:1,mobile:false});
  const result=await until(()=>liveEval(host,`(w,d)=>{const box=id=>d.getElementById(id).getBoundingClientRect();return {width:w.innerWidth,feed:box('feed').width,inspector:box('inspector').width,overflow:d.documentElement.scrollWidth>w.innerWidth};}`),x=>width<700?x.feed===0&&x.inspector>0:x.feed>0&&x.inspector>=360,'layout settled');
  assert.equal(result.overflow,false);
  const screenshot=await host.call('Page.captureScreenshot',{format:'png'});
  await writeFile(new URL(`evidence/live-${name}.png`,import.meta.url),Buffer.from(screenshot.data,'base64'));
  return result;
}
export async function bench(page,detector){
  return page.evaluate(`(()=>{const scan=${detector.toString()};const times=[];for(let i=0;i<100;i++){const t=performance.now();scan();times.push(performance.now()-t);}times.sort((a,b)=>a-b);return {samples:100,medianMs:times[50],p95Ms:times[95],maximumMs:times[99]};})()`);
}
