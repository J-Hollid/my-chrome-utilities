import {resolve} from 'node:path';
import {startBrowser,until} from './browser.mjs';
import {fixtureServer} from './fixtures.mjs';
const site=await fixtureServer(),browser=await startBrowser(['--auto-open-devtools-for-tabs']);
try {
  const extension=await browser.call('Extensions.loadUnpacked',{path:resolve('tmp/tealium-experiment/extension')});
  console.log({extension});
  const {targetId}=await browser.call('Target.createTarget',{url:site.origin+'/separate'});
  const targets=await until(()=>browser.call('Target.getTargets'),x=>x.targetInfos.some(t=>t.url.includes('/devtools.html')),'DevTools extension target',10000);
  console.log(JSON.stringify(targets,null,2));
}finally{await browser.close();site.close();}
