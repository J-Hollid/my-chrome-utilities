import http from 'node:http';
import { readFile, writeFile } from 'node:fs/promises';
import { startBrowser, until } from './browser.mjs';
const source = await readFile(new URL('vendor/utag.js', import.meta.url));
const requests = [];
const server = http.createServer((req, res) => {
  requests.push(req.url);
  if (req.url.startsWith('/custom/utag.js')) {
    res.setHeader('Content-Type', 'text/javascript'); res.end(source); return;
  }
  if (req.url !== '/') { res.writeHead(404); res.end(); return; }
  res.setHeader('Content-Type', 'text/html');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self'; frame-src 'none'");
  res.end(`<!doctype html><title>Isolated Tealium runtime</title><script>window.utag_data={tealium_event:'page_view'};window.utag_cfg_ovrd={path:location.origin+'/custom/'};</script><script src='/custom/utag.js?case=real'></script>`);
});
await new Promise(done => server.listen(0, '127.0.0.1', done));
const origin = `http://127.0.0.1:${server.address().port}`;
const browser = await startBrowser();
try {
  const { targetId } = await browser.call('Target.createTarget', { url: origin });
  const page = await browser.attach(targetId);
  await until(() => page.evaluate('({url:location.href,state:document.readyState})'), x => x.url === origin+'/' && x.state === 'complete', 'page load');
  const snapshot = await page.evaluate(`({keys:Object.keys(window.utag||{}), cfg:utag.cfg, data:utag.data, loader: Object.keys(utag.loader||{}), tags:utag.loader?.cfg, senders:Object.keys(utag.sender||{}), objects:Object.keys(utag.o||{}), ready:utag.handler?.iflag, scripts:[...document.scripts].map(s=>({id:s.id,src:s.src}))})`);
  await writeFile(new URL('evidence/runtime-inspection.json', import.meta.url), JSON.stringify({ version:browser.version, snapshot, requests }, null, 2));
  console.log(JSON.stringify({version:browser.version.product, keys:snapshot.keys, cfg:snapshot.cfg, tags:snapshot.tags, senders:snapshot.senders, objects:snapshot.objects, ready:snapshot.ready,scripts:snapshot.scripts,requests}, null, 2));
} finally { await browser.close(); server.close(); }
