import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {writeFile} from 'node:fs/promises';
import {startBrowser,until} from './browser.mjs';
import {fixtureServer} from './fixtures.mjs';
const started=Date.now(),site=await fixtureServer(),browser=await startBrowser(['--auto-open-devtools-for-tabs']);
const results=[];
try {
  const {id}=await browser.call('Extensions.loadUnpacked',{path:resolve('tmp/tealium-experiment/extension')});
  for(const [name,key,suffix] of [['separate','shop.main:21','/custom/utag.21.js?revision=exact'],['separate','shop.main:34','/custom/utag.js'],['custom','shop.main:52','/custom/vendor-special.js?v=52'],['real','tealium.docs:115','/custom/real-payload.js?revision=original']]) {
    const url=site.origin+'/'+name;
    const {targetId}=await browser.call('Target.createTarget',{url});
    const targets=await until(()=>browser.call('Target.getTargets'),r=>{
      const frontend=r.targetInfos.find(t=>t.url.startsWith('devtools://')&&t.title.endsWith('/'+name));
      return frontend&&r.targetInfos.some(t=>t.parentId===frontend.targetId&&t.url===`chrome-extension://${id}/devtools.html`);
    },'DevTools connection',10000);
    const frontendInfo=targets.targetInfos.find(t=>t.url.startsWith('devtools://')&&t.title.endsWith('/'+name));
    const bridgeInfo=targets.targetInfos.find(t=>t.parentId===frontendInfo.targetId&&t.url===`chrome-extension://${id}/devtools.html`);
    const bridge=await browser.attach(bridgeInfo.targetId),frontend=await browser.attach(frontendInfo.targetId);
    await until(()=>bridge.evaluate('Boolean(window.experiment)'),Boolean,'bridge ready');
    const opened=await bridge.evaluate(`experiment.showTag(${JSON.stringify(key)},${JSON.stringify(url)})`);
    assert.equal(opened.url,site.origin+suffix);
    const selected=await until(()=>frontend.evaluate(`(async()=>{const S=await import('./panels/sources/sources.js');const view=S.SourcesPanel.SourcesPanel.instance().sourcesView();const frame=view.currentSourceFrame();const state=frame?.textEditor?.state;return {url:view.currentUISourceCode()?.url(),length:state?.doc?.length,selection:state?.selection?.main?.head,line:state?state.doc.lineAt(state.selection.main.head).number:null,lineText:state?state.doc.lineAt(state.selection.main.head).text:null};})()`),value=>value.url===opened.url&&value.length>0,'Sources text displayed');
    assert.equal(selected.url,opened.url);
    const shot=await frontend.call('Page.captureScreenshot',{format:'png'});
    await writeFile(new URL(`evidence/sources-${name}-${key.split(':')[1]}.png`,import.meta.url),Buffer.from(shot.data,'base64'));
    if(opened.evidence==='Exact registered function found in resource') {
      const signature=await bridge.evaluate(`experiment.snapshot().then(s=>s.tags.find(t=>t.key===${JSON.stringify(key)}).sendSource.split('{')[0].replace(/\\s/g,''))`);
      assert(selected.lineText.replace(/\s/g,'').includes(signature),JSON.stringify({signature,selected}));
    }
    results.push({case:`${name} ${key}`,status:'passed',opened,editor:selected});
    const page=await browser.attach(targetId);
    await page.call('Page.navigate',{url:site.origin+'/absent'});
    await until(()=>page.evaluate('location.href'),value=>value===site.origin+'/absent','navigation');
    const stale=await bridge.evaluate(`experiment.showTag(${JSON.stringify(key)},${JSON.stringify(url)}).then(()=>({accepted:true}),error=>({accepted:false,error:error.message}))`);
    assert.equal(stale.accepted,false);assert.equal(stale.error,'Stale page selection');
    results.push({case:`stale ${name} ${key}`,status:'passed'});
    await browser.call('Target.closeTarget',{targetId});
  }
  const report={startedAt:new Date(started).toISOString(),elapsedMs:Date.now()-started,browser:browser.version,results};
  await writeFile(new URL('evidence/stage2.json',import.meta.url),JSON.stringify(report,null,2));
  console.log(JSON.stringify(report,null,2));
}finally{await browser.close();site.close();}
